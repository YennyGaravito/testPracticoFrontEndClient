import React from 'react';
import PropTypes from 'prop-types';
import { useParams } from "react-router-dom";

export default function Detalle({ descrip }) {
  const { id } = useParams();
  return(
    <div>
      <h3>Este es el item {id}</h3>
    </div>
  )
}

Detalle.propTypes = {
  descrip: PropTypes.string.isRequired
}