import React, { Component } from 'react';
import "../styles/busqueda.css"
import ResultadoBusqueda from '../resultado/resultadoBusqueda'

export default class Busqueda extends Component {
  render() {
  return(
    <div>
      <h3>Busqueda</h3>
      <form className="nav-busqueda">
          <img src="https://http2.mlstatic.com/frontend-assets/ui-navigation/5.18.9/mercadolibre/logo__small.png"></img>
          <input type="text" className="nav-busqueda-input"
            name="txtBuscar" placeholder="Buscar productos" maxLength="120"
            autoCorrect="off" autoComplete="off"
            id="txtBuscar"/>
            <button type="submit" className="nav-busqueda-btn">
            </button>
      </form>
    </div>
  )}
}
