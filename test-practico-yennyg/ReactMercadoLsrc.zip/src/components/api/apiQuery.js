import React from 'react';
import ResultadoBusqueda from '../resultado/resultadoBusqueda';
import axios from 'axios';

class ApiQuery extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            productos : [{}],
            isLoading: true
        }
    }

    componentWillMount() {      
        const apiUrl = 'https://api.mercadolibre.com/sites/MLA/search?q=' + 'mouse';
        axios.get(apiUrl)
        .then(res => {
            this.state.productos = res.data.results;
            this.setState({
                productos: res.data.results,
                isLoading: false
            });
            console.log(this.state.productos);
        });
    }


    transformData(productos) {
        let prodVistaArray = [];
        let categoriesArray = [];
        productos.map(prod => {
            if(prodVistaArray.length < 4) {
                prodVistaArray.push({
                    id: prod.id,
                    title: prod.title,
                    price: { 
                        currency: prod.currency_id,
                        amount: prod.price,
                        decimals: 0
                    },
                    picture: prod.thumbnail,
                    condition: prod.condition,
                    free_shipping: prod.shipping.free_shipping
                });
                categoriesArray.push(prod.category_id);
            }
        });
        const resultado = {
            queryResult: {
                author: {
                    name: "Yenny Carolina",
                    lastName: "Garavito"
                },
                categories: categoriesArray,
                items: prodVistaArray
            }
        };
        return resultado;
    }

    render() {
        if (this.state.isLoading === false) {
            return(
                    <div>
                        Encontro resultados
                        {this.state.productos.length}
                        <div>
                            <ResultadoBusqueda productos={this.transformData(this.state.productos).queryResult.items}></ResultadoBusqueda>
                        </div>
                    </div>
            )
        }
    }
}

export default ApiQuery;