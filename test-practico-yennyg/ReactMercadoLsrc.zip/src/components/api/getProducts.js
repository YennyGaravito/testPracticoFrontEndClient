
function createProductos(prod, limit = 4) {
    const result = [];

    for (let i = 0; i < limit; i++) {
        const name = "Yenny";
        result.push({
            id: prod.id,
            title: prod.title,
            price: { 
                currency: prod.currency_id,
                amount: prod.price,
                decimals: 0
            },
            picture: prod.thumbnail,
            condition: prod.condition,
            free_shipping: prod.shipping.free_shipping
        });
    }
    return result;
}

export default function llamarBusqueda(buscar) {
    const apiUrl = 'https://api.mercadolibre.com/sites/MLA/search?q=' + buscar;
    let resultado;
    fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => {
           resultado = data.results
        })
        .catch(console.log);
    return resultado;
}
