
import React from 'react';
import { useParams } from "react-router-dom";

export default function ApiDetalle() {
    function traerProductoData(buscar) {
        const apiUrlGeneral = 'https://api.mercadolibre.com/items/' + buscar;
        let itemProducto = {};
        fetch(apiUrlGeneral)
          .then((response) => response.json())
          .then((data) => (
            itemProducto = {
                "author": { 
                    "name": "Yenny",
                    "lastname": "Garavito"
                },
                "item": {
                    "id": data.attributes.id,
                    "title":  data.title,
                    "price": {
                        "currency": data.currency_id,
                        "amount": data.price,
                        "decimals": 0,
                    },
                "picture": data.pictures.url,
                "condition": data.condition.new,
                "free_shipping": data.shipping.free_shipping,
                "sold_quantity": data.sold_quantity,
                "description": ""
                }
            })
          );
        //itemProducto.description = traerDescripcion(buscar);
        return itemProducto;
    }
    
    function traerDescripcion(buscarId) {
        const apiUrlDescription = 'https://api.mercadolibre.com/items/' + buscarId + '/description';
        let descriptionBus;
        fetch(apiUrlDescription)
          .then((response) => response.json())
          .then((data) => {
            descriptionBus = data.plain_text;
          })
          .catch(console.log);
          return descriptionBus;
    }

  const { id } = useParams();
  const { resulProd } = traerProductoData(id);
  return(
    <div>
      <h3>Detalle del item {id}</h3>
      <span>
        {
          resulProd
        }
        </span>
    </div>
  )
}