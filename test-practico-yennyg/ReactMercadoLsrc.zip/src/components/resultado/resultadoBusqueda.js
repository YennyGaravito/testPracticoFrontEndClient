import React from 'react';
import "../styles/resultadoBusqueda.css"

class ItemLista extends React.Component {
  handleClick = e => {
    e.preventDefault();
    console.log(e.target.value);
  }

  render() {
    return(
      <div className='list-item'>
        <img 
          className='list-item__img'
          onCLick={this.handleClick}
          src={this.props.producto.picture}
          alt={this.props.producto.title} />
        <div className='list-item__info'>
            <strong>
              {this.props.producto.title}
            </strong>
            <br />
            {this.props.producto.price.amount}
            <br />
            {this.props.producto.condition}
        </div>
      </div>
    );
  }
}

class ResultadoBusqueda extends React.Component {
  constructor(props) {
    super(props);
    console.log(props);
  }

  render() {
    return (
      <div className='lista-container'>
        <h4>Busqueda: resultados aqui</h4>
        <ul className='lista-unstyled'>
          {this.props.productos.map(prod => {
            return(
              <li key={prod.id}>
                <ItemLista producto={prod} />
              </li>
            );
          })
          }
        </ul>
      </div>
    );
  }
}

export default ResultadoBusqueda;