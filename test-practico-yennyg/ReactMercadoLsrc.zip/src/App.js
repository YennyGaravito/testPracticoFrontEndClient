import React, { useEffect } from 'react';
import { Route, Routes } from "react-router-dom";
import Busqueda from './components/busqueda/busqueda';
import Detalle from './components/detalle/detalleProducto';
import ResultadoBusqueda from './components/resultado/resultadoBusqueda';
import ApiQuery from './components/api/apiQuery';
import ApiDetalle from './components/api/apiDetalle';
import { useParams } from "react-router-dom";

export default function App() {
  let { search } = useParams();
  return (
    <div>
      {
      <Busqueda></Busqueda>
      }
      <Routes> 
        <Route exact path="/" element=
          {
            <Busqueda></Busqueda>
          }
        />
        <Route exact path="/items/:id" element=
          {
            <Detalle descrip="otra"></Detalle>
          }
        />
        <Route exact path="/search/:search"  element=
          {
            <ResultadoBusqueda></ResultadoBusqueda>
          }
        />
        <Route exact path="/api/items/:id" element=
          {
            <ApiDetalle></ApiDetalle>
          }
        />
        <Route path="/api/items/search/:search" element=
          {
            <ApiQuery buscar={search}></ApiQuery>
          }
        />
        <Route path="*" element=
          {
            <Busqueda></Busqueda>
          }
        />
      </Routes>
      <div>
        <h5>Developed by YennyG</h5>
      </div>
    </div>
  );
}
